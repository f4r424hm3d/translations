<?php


return [

  'welcome' => 'Bienvenue dans les traductions de Laravel 10 par Mohammad Faraz'

];
