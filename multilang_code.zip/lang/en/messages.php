<?php


return [

  'welcome' => 'Welcome to the Laravel 10 translations by Mohammad Faraz'

];
