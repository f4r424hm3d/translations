<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http; // For making HTTP requests

class RedirectBasedOnGeolocation
{
  public function handle($request, Closure $next)
  {
    // Get user's IP address
    $ip = $request->ip();

    // Fetch geolocation data from an API
    $response = Http::get('https://ipapi.co/' . $ip . '/json/');
    $locationData = $response->json();

    // Get the country code
    $countryCode = $locationData['country_code'] ?? 'EN';

    // Check if the country code corresponds to a language in the database
    $language = DB::table('languages')->where('code', strtolower($countryCode))->first();

    if ($language) {
      $languageCode = $language->code;
      $url = $request->getRequestUri();

      if (!str_starts_with($url, '/' . $languageCode)) {
        return redirect('/' . $languageCode . $url);
      }
    }

    return $next($request);
  }
}
